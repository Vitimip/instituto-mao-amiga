import { useState } from 'react';
import { View, Text, Image, Button, StyleSheet } from 'react-native';

type Ponto = {
  id: string;
  endereco: string;
  horario: string;
  recebe_distribui: string;
};

const pontosMock: Ponto[] = [
  {id: '1', endereco: 'Av do Miojo', horario: '13:00', recebe_distribui: 'Arroz'},
  {id: '2', endereco: 'Rua dos queijos', horario: '14:00', recebe_distribui: 'Papel Higienico'},
  {id: '3', endereco: 'Av dos coquinhos', horario: '22:00', recebe_distribui: 'Pasta de dente'},
];


function PontoItem({ ponto }: { ponto: Ponto }) {
  const [favorito, setFavorito] = useState(false);

  return (
      <View style={styles.item}>
        <View style={styles.info}>
          <Text>{ponto.endereco}</Text>
          <Text>{ponto.horario}</Text>
          <Text>{ponto.recebe_distribui}</Text>
        </View>
        <Button
            title={favorito ? '♥' : '♡'}
            onPress={() => setFavorito(!favorito)}
        />
      </View>
  );
}

export default function TelaListaPontos() {


  //HTML
  return (
      <View style={styles.container}>
        {pontosMock.map((ponto) => (
            <PontoItem key={ponto.id} ponto={ponto} />
        ))}
      </View>
  );
}





//CSS
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#FFFFFF',
  },
  item: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E0E0E0',
  },
  imagem: {
    width: 64,
    height: 64,
    borderRadius: 8,
    marginRight: 12,
  },
  info: {
    flex: 1,
  },
  nome: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#1B3A5C',
  },
  preco: {
    fontSize: 15,
    fontWeight: '600',
    color: '#2E7D32',
    marginTop: 4,
  },
});

