
import { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import {
    createNativeStackNavigator,
} from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import TelaListaPontos, {
    pontosIniciais,
    type Ponto,
} from './TelaListaPontos';
import TelaDetalhePonto from './TelaDetalhePonto';


export type RootStackParamList = {
    ListaPontos: undefined;
    DetalhePonto: { pontoId: string } | undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();

export default function App() {
    const [pontos, setPontos] = useState<Ponto[]>(pontosIniciais);

    function adicionarPonto(ponto: Ponto) {
        setPontos((atual) => [...atual, ponto]);
    }

    return (
        <SafeAreaProvider>
            <NavigationContainer>
                <Stack.Navigator initialRouteName="ListaPontos">

                    <Stack.Screen name="ListaPontos">
                        {(props) => (
                            <TelaListaPontos
                                {...props}
                                pontos={pontos}
                                onAdicionarPonto={adicionarPonto}
                            />
                        )}
                    </Stack.Screen>

                    <Stack.Screen name="DetalhePonto">
                        {(props) => (
                            <TelaDetalhePonto
                                {...props}
                                pontos={pontos}
                            />
                        )}
                    </Stack.Screen>

                </Stack.Navigator>
            </NavigationContainer>
        </SafeAreaProvider>
    );
}